import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import Reveal from "./Reveal";

const photos = [
  {
    src: "https://images.unsplash.com/photo-1540518614846-7eded433c457?auto=format&fit=crop&w=1400&q=80",
    alt: "Giường ngủ tông trắng ngà với ánh nắng sớm qua rèm voan",
    w: 1400,
    h: 1750,
  },
  {
    src: "https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&w=1400&q=80",
    alt: "Phòng tắm đá cẩm thạch với bồn tắm độc lập",
    w: 1400,
    h: 933,
  },
  {
    src: "https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1400&q=80",
    alt: "Khu spa với nến thơm và khăn cuộn gọn",
    w: 1400,
    h: 1750,
  },
  {
    src: "https://images.unsplash.com/photo-1551882547-ff40c63fe5fa?auto=format&fit=crop&w=1400&q=80",
    alt: "Hồ bơi vô cực nhìn ra biển lúc hoàng hôn",
    w: 1400,
    h: 933,
  },
  {
    src: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?auto=format&fit=crop&w=1400&q=80",
    alt: "Mặt tiền khách sạn với kiến trúc đường nét tối giản",
    w: 1400,
    h: 1866,
  },
  {
    src: "https://images.unsplash.com/photo-1455587734955-081b22074882?auto=format&fit=crop&w=1400&q=80",
    alt: "Ban công phòng suite với ghế mây nhìn ra vịnh",
    w: 1400,
    h: 933,
  },
];

export default function Gallery() {
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  useEffect(() => {
    document.body.style.overflow = active !== null ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [active]);

  return (
    <section
      id="thu-vien"
      data-jiro-section="gallery"
      data-jiro-label="Thư viện ảnh"
      className="bg-[#FAF8F4] px-5 py-20 md:px-10 md:py-32"
    >
      <div className="mx-auto max-w-6xl">
        <Reveal className="text-center">
          <p className="text-[11px] tracking-[0.3em] text-[#B8975A] uppercase">Thư viện</p>
          <h2 className="mt-5 font-display text-4xl leading-tight font-light md:text-5xl">
            Một ngày ở Lumière
          </h2>
        </Reveal>

        <div className="mt-12 columns-2 gap-4 md:mt-20 md:columns-3 md:gap-6">
          {photos.map((p, i) => (
            <Reveal key={p.src} delay={(i % 3) * 0.08} className="mb-4 break-inside-avoid md:mb-6">
              <button
                type="button"
                onClick={() => setActive(i)}
                aria-label={`Phóng to ảnh: ${p.alt}`}
                className="group relative block w-full overflow-hidden bg-[#1C1B19] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
              >
                <img
                  key={p.src}
                  src={p.src}
                  alt={p.alt}
                  width={p.w}
                  height={p.h}
                  loading="lazy"
                  className="w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]"
                />
                <span className="absolute inset-0 bg-[#14130F]/0 transition-colors duration-[400ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:bg-[#14130F]/25" />
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      <AnimatePresence>
        {active !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="fixed inset-0 z-[60] flex items-center justify-center bg-[#14130F]/95 p-4 backdrop-blur-sm md:p-10"
            onClick={() => setActive(null)}
            role="dialog"
            aria-modal="true"
            aria-label="Ảnh phóng to"
          >
            <button
              type="button"
              onClick={() => setActive(null)}
              aria-label="Đóng ảnh"
              className="absolute top-5 right-5 p-2 text-[#F3EEE4]/70 transition-colors duration-300 hover:text-[#B8975A] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none md:top-8 md:right-8"
            >
              <X size={24} strokeWidth={1.2} />
            </button>
            <motion.img
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
              key={photos[active].src}
              src={photos[active].src}
              alt={photos[active].alt}
              width={photos[active].w}
              height={photos[active].h}
              loading="lazy"
              className="max-h-[85vh] w-auto max-w-full object-contain"
              onClick={(e) => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
