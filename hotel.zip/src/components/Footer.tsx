import { Facebook, Instagram, Youtube } from "lucide-react";

const nav = [
  { label: "Giới thiệu", href: "#gioi-thieu" },
  { label: "Phòng & Suite", href: "#phong-suite" },
  { label: "Tiện ích", href: "#tien-ich" },
  { label: "Ẩm thực", href: "#am-thuc" },
  { label: "Thư viện", href: "#thu-vien" },
  { label: "Đặt phòng", href: "#dat-phong" },
];

const socials = [
  { icon: Instagram, label: "Instagram", href: "https://instagram.com" },
  { icon: Facebook, label: "Facebook", href: "https://facebook.com" },
  { icon: Youtube, label: "YouTube", href: "https://youtube.com" },
];

export default function Footer() {
  return (
    <footer
      data-jiro-section="footer"
      data-jiro-label="Footer"
      className="bg-[#14130F] px-5 py-16 text-[#F3EEE4] md:px-10 md:py-20"
    >
      <div className="mx-auto max-w-6xl">
        <div className="grid gap-12 md:grid-cols-12 md:gap-10">
          <div className="md:col-span-5">
            <p className="font-display text-2xl tracking-[0.3em] uppercase">Lumière</p>
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-[#F3EEE4]/55">
              Khách sạn 5 sao bên vịnh Đà Nẵng. Nhận phòng 14:00 · Trả phòng 12:00.
            </p>
          </div>

          <nav aria-label="Điều hướng chân trang" className="md:col-span-4">
            <ul className="grid grid-cols-2 gap-x-6 gap-y-3">
              {nav.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="group relative inline-block text-[11px] tracking-[0.18em] text-[#F3EEE4]/60 uppercase transition-colors duration-[400ms] hover:text-[#F3EEE4] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
                  >
                    {l.label}
                    <span className="absolute -bottom-1 left-0 h-px w-0 bg-[#B8975A] transition-all duration-[400ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:w-full" />
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div className="md:col-span-3">
            <p className="text-sm leading-relaxed text-[#F3EEE4]/55">
              12 Võ Nguyên Giáp, Ngũ Hành Sơn
              <br />
              Đà Nẵng, Việt Nam
            </p>
            <p className="mt-4 text-sm text-[#F3EEE4]/55">
              <a
                href="tel:+842363888888"
                className="transition-colors duration-300 hover:text-[#B8975A] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
              >
                +84 236 3888 888
              </a>
            </p>
            <ul className="mt-6 flex gap-4">
              {socials.map((s) => (
                <li key={s.label}>
                  <a
                    href={s.href}
                    target="_blank"
                    rel="noreferrer"
                    aria-label={s.label}
                    className="inline-block text-[#F3EEE4]/55 transition-colors duration-[400ms] hover:text-[#B8975A] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
                  >
                    <s.icon size={18} strokeWidth={1.1} />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-[#F3EEE4]/10 pt-6 text-[10px] tracking-[0.18em] text-[#F3EEE4]/35 uppercase sm:flex-row sm:items-center sm:justify-between">
          <p>© 2025 Lumière Hotel Đà Nẵng</p>
          <p>Chính sách riêng tư · Điều khoản lưu trú</p>
        </div>
      </div>
    </footer>
  );
}
