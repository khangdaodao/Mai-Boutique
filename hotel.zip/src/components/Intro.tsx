import Reveal from "./Reveal";

const IMG =
  "https://images.unsplash.com/photo-1445019980597-93fa8acb246c?auto=format&fit=crop&w=1200&q=80";

export default function Intro() {
  return (
    <section
      id="gioi-thieu"
      data-jiro-section="intro"
      data-jiro-label="Giới thiệu"
      className="bg-[#FAF8F4] px-5 py-20 md:px-10 md:py-32"
    >
      <div className="mx-auto grid max-w-6xl items-center gap-12 md:grid-cols-12 md:gap-20">
        <Reveal className="md:col-span-7">
          <p className="text-[11px] tracking-[0.3em] text-[#B8975A] uppercase">Lumière Hotel</p>
          <h2 className="mt-6 font-display text-4xl leading-[1.15] font-light md:text-5xl">
            Tĩnh lặng giữa lòng thành phố,
            <br className="hidden md:block" /> hướng trọn ra biển.
          </h2>
          <p className="mt-8 max-w-prose leading-relaxed text-[#6F6A62]">
            86 phòng và suite nhìn ra vịnh, một spa trầm hương, hai nhà hàng. Chúng tôi giữ mọi thứ
            thật giản dị — để điều bạn nhớ là ánh sáng buổi sớm trên mặt nước.
          </p>
          <div className="mt-10 flex flex-wrap gap-x-12 gap-y-6">
            {[
              { k: "86", v: "Phòng & Suite" },
              { k: "2", v: "Nhà hàng" },
              { k: "24/7", v: "Quản gia riêng" },
            ].map((s) => (
              <div key={s.v}>
                <p className="font-display text-3xl font-light text-[#1C1B19]">{s.k}</p>
                <p className="mt-1 text-[10px] tracking-[0.18em] text-[#6F6A62] uppercase">{s.v}</p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.15} className="md:col-span-5">
          <div className="group relative overflow-hidden">
            <img
              key={IMG}
              src={IMG}
              alt="Sảnh khách sạn với ánh sáng ấm và đồ nội thất gỗ tối giản"
              width={1200}
              height={1600}
              loading="lazy"
              className="aspect-[3/4] w-full object-cover transition-transform duration-[900ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]"
            />
          </div>
        </Reveal>
      </div>
    </section>
  );
}
