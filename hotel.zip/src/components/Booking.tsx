import { useState } from "react";
import { MapPin, Phone, Mail } from "lucide-react";
import Reveal from "./Reveal";

const roomTypes = [
  "Deluxe Hướng Vườn",
  "Premier Hướng Biển",
  "Junior Suite",
  "Lumière Signature Suite",
  "Penthouse Vịnh",
];

const fieldClass =
  "mt-2 w-full border-b border-[#1C1B19]/20 bg-transparent py-2.5 text-sm text-[#1C1B19] outline-none transition-colors duration-[400ms] ease-[cubic-bezier(.22,1,.36,1)] focus:border-[#B8975A] focus-visible:ring-0";
const labelClass = "block text-[10px] tracking-[0.18em] text-[#6F6A62] uppercase";

export default function Booking() {
  const [form, setForm] = useState({
    name: "",
    contact: "",
    arrive: "",
    depart: "",
    guests: "2",
    room: roomTypes[0],
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const body = [
      `Họ tên: ${form.name}`,
      `Liên hệ: ${form.contact}`,
      `Ngày đến: ${form.arrive}`,
      `Ngày đi: ${form.depart}`,
      `Số khách: ${form.guests}`,
      `Loại phòng: ${form.room}`,
    ].join("\n");
    window.location.href = `mailto:datphong@lumiere-hotel.vn?subject=${encodeURIComponent(
      "Yêu cầu đặt phòng — Lumière"
    )}&body=${encodeURIComponent(body)}`;
  };

  return (
    <section
      id="dat-phong"
      data-jiro-section="booking"
      data-jiro-label="Đặt phòng / Liên hệ"
      className="bg-[#F0EBE2] px-5 py-20 md:px-10 md:py-32"
    >
      <div className="mx-auto grid max-w-6xl gap-14 md:grid-cols-2 md:gap-20">
        <Reveal>
          <p className="text-[11px] tracking-[0.3em] text-[#B8975A] uppercase">Đặt phòng</p>
          <h2 className="mt-5 font-display text-4xl leading-tight font-light md:text-5xl">
            Gửi yêu cầu, chúng tôi hồi đáp trong 2 giờ.
          </h2>

          <form onSubmit={onSubmit} className="mt-10 grid grid-cols-1 gap-7 sm:grid-cols-2">
            <label className="sm:col-span-1">
              <span className={labelClass}>Họ và tên</span>
              <input
                required
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Nguyễn Minh Anh"
                className={fieldClass}
              />
            </label>
            <label className="sm:col-span-1">
              <span className={labelClass}>Email hoặc điện thoại</span>
              <input
                required
                type="text"
                value={form.contact}
                onChange={(e) => setForm({ ...form, contact: e.target.value })}
                placeholder="minhanh@email.com"
                className={fieldClass}
              />
            </label>
            <label>
              <span className={labelClass}>Ngày đến</span>
              <input
                type="date"
                value={form.arrive}
                onChange={(e) => setForm({ ...form, arrive: e.target.value })}
                className={fieldClass}
              />
            </label>
            <label>
              <span className={labelClass}>Ngày đi</span>
              <input
                type="date"
                value={form.depart}
                onChange={(e) => setForm({ ...form, depart: e.target.value })}
                className={fieldClass}
              />
            </label>
            <label>
              <span className={labelClass}>Số khách</span>
              <select
                value={form.guests}
                onChange={(e) => setForm({ ...form, guests: e.target.value })}
                className={fieldClass}
              >
                {["1", "2", "3", "4", "5+"].map((n) => (
                  <option key={n} value={n}>
                    {n} khách
                  </option>
                ))}
              </select>
            </label>
            <label>
              <span className={labelClass}>Loại phòng</span>
              <select
                value={form.room}
                onChange={(e) => setForm({ ...form, room: e.target.value })}
                className={fieldClass}
              >
                {roomTypes.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </label>

            <div className="sm:col-span-2">
              <button
                type="submit"
                className="w-full bg-[#B8975A] px-8 py-4 text-[11px] tracking-[0.18em] text-[#14130F] uppercase transition-colors duration-[400ms] ease-[cubic-bezier(.22,1,.36,1)] hover:bg-[#1C1B19] hover:text-[#F3EEE4] focus-visible:ring-2 focus-visible:ring-[#1C1B19] focus-visible:outline-none sm:w-auto"
              >
                Gửi yêu cầu đặt phòng
              </button>
              <p className="mt-4 text-xs leading-relaxed text-[#6F6A62]">
                Nút này mở sẵn email gửi tới lễ tân — không có khoản thanh toán nào được thực hiện tại
                đây.
              </p>
            </div>
          </form>
        </Reveal>

        <Reveal delay={0.15}>
          <div className="overflow-hidden border border-[#1C1B19]/10">
            <iframe
              title="Bản đồ vị trí khách sạn Lumière"
              src="https://www.google.com/maps?q=V%C3%B5%20Nguy%C3%AAn%20Gi%C3%A1p%2C%20Ng%C5%A9%20H%C3%A0nh%20S%C6%A1n%2C%20%C4%90%C3%A0%20N%E1%BA%B5ng&output=embed"
              width="600"
              height="400"
              loading="lazy"
              className="h-[280px] w-full grayscale-[0.4] md:h-[340px]"
              style={{ border: 0 }}
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <ul className="mt-10 space-y-6">
            <li className="flex gap-4">
              <MapPin size={18} strokeWidth={1.1} className="mt-0.5 shrink-0 text-[#B8975A]" />
              <p className="text-sm leading-relaxed text-[#6F6A62]">
                12 Võ Nguyên Giáp, Ngũ Hành Sơn
                <br />
                Đà Nẵng, Việt Nam
              </p>
            </li>
            <li className="flex gap-4">
              <Phone size={18} strokeWidth={1.1} className="mt-0.5 shrink-0 text-[#B8975A]" />
              <a
                href="tel:+842363888888"
                className="group text-sm text-[#1C1B19] transition-colors duration-300 hover:text-[#B8975A] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
              >
                +84 236 3888 888
              </a>
            </li>
            <li className="flex gap-4">
              <Mail size={18} strokeWidth={1.1} className="mt-0.5 shrink-0 text-[#B8975A]" />
              <a
                href="mailto:datphong@lumiere-hotel.vn"
                className="text-sm text-[#1C1B19] transition-colors duration-300 hover:text-[#B8975A] focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
              >
                datphong@lumiere-hotel.vn
              </a>
            </li>
          </ul>
        </Reveal>
      </div>
    </section>
  );
}
