import Reveal from "./Reveal";

const places = [
  {
    name: "Mây",
    kind: "Nhà hàng Việt đương đại",
    line: "Hải sản vịnh Đà Nẵng, nấu mộc, dọn theo mùa.",
    hours: "17:30 – 22:30",
    img: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1400&q=80",
    alt: "Không gian nhà hàng Mây với bàn gỗ và ánh đèn ấm",
  },
  {
    name: "Côte",
    kind: "Bistro Pháp · Bữa sáng",
    line: "Bánh mì nướng mỗi sáng, cà phê rang tại chỗ.",
    hours: "06:30 – 14:00",
    img: "https://images.unsplash.com/photo-1414235077428-338989a2e8c0?auto=format&fit=crop&w=1400&q=80",
    alt: "Bistro Côte với cửa kính lớn và bàn ăn sáng bày sẵn",
  },
  {
    name: "Tầng 21",
    kind: "Rooftop bar",
    line: "Cocktail chữ ký, nhạc mộc, trọn tầm nhìn ra biển.",
    hours: "16:00 – 00:00",
    img: "https://images.unsplash.com/photo-1470337458703-46ad1756a187?auto=format&fit=crop&w=1400&q=80",
    alt: "Quầy bar trên sân thượng với ly cocktail và ánh hoàng hôn",
  },
];

export default function Dining() {
  return (
    <section
      id="am-thuc"
      data-jiro-section="dining"
      data-jiro-label="Ẩm thực"
      className="bg-[#14130F] px-5 py-20 text-[#F3EEE4] md:px-10 md:py-32"
    >
      <div className="mx-auto max-w-6xl">
        <Reveal>
          <p className="text-[11px] tracking-[0.3em] text-[#B8975A] uppercase">Ẩm thực</p>
          <h2 className="mt-5 max-w-xl font-display text-4xl leading-tight font-light md:text-5xl">
            Ba không gian, một nhịp ngày.
          </h2>
        </Reveal>

        <div className="mt-14 space-y-16 md:mt-24 md:space-y-28">
          {places.map((p, i) => (
            <Reveal key={p.name} delay={0.05}>
              <article
                className={`group grid items-center gap-8 md:grid-cols-2 md:gap-16 ${
                  i % 2 === 1 ? "md:[&>figure]:order-2" : ""
                }`}
              >
                <figure className="overflow-hidden bg-[#1C1B19]">
                  <img
                    key={p.img}
                    src={p.img}
                    alt={p.alt}
                    width={1400}
                    height={1000}
                    loading="lazy"
                    className="aspect-[7/5] w-full object-cover opacity-95 transition-transform duration-[900ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover:scale-[1.05]"
                  />
                </figure>
                <div>
                  <p className="text-[10px] tracking-[0.22em] text-[#B8975A] uppercase">{p.kind}</p>
                  <h3 className="mt-4 font-display text-3xl font-light md:text-4xl">{p.name}</h3>
                  <p className="mt-4 max-w-prose leading-relaxed text-[#F3EEE4]/65">{p.line}</p>
                  <p className="mt-6 text-[10px] tracking-[0.18em] text-[#F3EEE4]/45 uppercase">
                    Mỗi ngày · {p.hours}
                  </p>
                  <a
                    href="#dat-phong"
                    className="group/link mt-8 inline-block text-[11px] tracking-[0.18em] text-[#F3EEE4] uppercase focus-visible:ring-2 focus-visible:ring-[#B8975A] focus-visible:outline-none"
                  >
                    Đặt bàn
                    <span className="mt-1 block h-px w-0 bg-[#B8975A] transition-all duration-[400ms] ease-[cubic-bezier(.22,1,.36,1)] group-hover/link:w-full" />
                  </a>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
